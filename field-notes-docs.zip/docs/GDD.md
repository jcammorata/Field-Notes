# Field Notes — Game Design Document

Nov 7, 2026 · @Joe Cammorata · Draft

> This file is the master copy of the GDD. Update it here as decisions are made. The claude.ai links below are private to the project owner and are no longer updated.

## At a glance

*Field Notes* is a beautiful, story-driven adventure where kids learn to think like scientists by figuring out the creatures of strange worlds, then use what they learn to restore an ancient treehouse that once guided a great migration between worlds.

|  |  |
| --- | --- |
| Working title | Field Notes |
| Genre | Exploration adventure: light platforming and point-and-click discovery |
| Platform | iOS and Android phones and tablets, landscape |
| Audience | Ages 7–12, with the core experience tuned for 7–10 |
| Engine | Godot |
| Length | 5–8 hours for the main story, more for full journal completion |
| Session length | 10–20 minutes |
| Inspirations | Pajama Sam (discovery and humor), Hollow Knight, Limbo and Maskborne (atmosphere and art), Alba and Botanicula (gentle exploration) |
| Unique hook | A personal field journal where kids draw, name and test creatures; understanding a creature is how you progress |

## Pillars and learning goals

Every feature must serve at least one of three pillars; anything that serves none gets rethought or cut.

- **Discovery.** Kids find out how the world works by watching and testing it.
- **Ingenuity.** Kids make things: builds, item combinations, drawings and unexpected solutions.
- **Problem-solving.** Kids reason through puzzles and learn from wrong guesses.

All three rest on one foundation: a beautiful world where mistakes are safe. The pillars diagram lives in the [core game loop doc](https://claude.ai/artifact/Tw9KMmzK6YoGX49a2VmuBR).

What kids should come away with:

- **The scientific method:** observe, guess, test, and treat a wrong guess as useful information.
- **Ecosystems:** food chains, habitats, predator and prey, how changing one thing affects others, and what happens when migrating creatures disappear.
- **Creature behavior and adaptation:** why creatures act as they do, each linked to a "real-world cousin" in its journal entry.
- **Simple machines:** levers, pulleys and ramps, through treehouse building.
- **Creative confidence:** their own drawings, names and ideas are part of the game.

## Learning design

Five rules keep the learning honest; the decisions behind them are listed below with proposals to confirm or change.

1. Every creature behavior is based on a real one.
2. Every journal entry has a real-world cousin card.
3. Fantasy is limited to travel and story.
4. A science educator reviews the content.
5. Playtests include a simple before-and-after check.

| Area | Decision | Proposal |
| --- | --- | --- |
| Creature behaviors | How far can a creature exaggerate a real behavior? | Exaggerate size, look and effect; keep the cause real |
| Creature behaviors | Who verifies each real behavior? | The designer researches it; the science reviewer confirms it before the creature is built |
| Cousin cards | What is on each card? | The real creature's name, one surprising fact, where it lives, and an illustration |
| Cousin cards | Photo or illustration? | Illustration in the journal style, which also avoids photo licensing |
| Cousin cards | When does a card unlock? | Undecided: after the first confirmed fact, or when the entry is complete |
| Cousin cards | Reading level | One or two short sentences, with read-aloud |
| Fantasy | What may be fantastical? | The beacons, mural doors, blight and ancients; creatures, physics and building stay real |
| Fantasy | How are gray areas framed? | The companion's wings as a kind of metamorphosis; the blight mirroring mold or invasive species |
| Fantasy | Does the journal mark which facts are real-world? | Undecided |
| Educator review | Who reviews? | A classroom science teacher for age fit, plus a biologist for accuracy if budget allows |
| Educator review | When? | Each world at the concept stage, and once before launch |
| Educator review | Curriculum alignment? | Only if selling to schools; the standards depend on the country |
| Playtest check | What is measured? | Reasoning first: can kids predict and test? |
| Playtest check | Format | Three to five picture-based questions, asked aloud |
| Playtest check | When? | At the systems prototype and the vertical slice |
| Playtest check | Consent and data | Written parent permission; answers stored without names |
| Public claims | What does the game promise? | Only what testing supports, such as "learn to think like scientists" |

## Story and setting

A kid helps a lost creature home and finds a ruined treehouse that once guided a migration of creatures between worlds. Restoring it room by room makes the kid its next caretaker.

**The opening.** Near the woods by the kid's home, they find a small, clumsy creature that is clearly lost: a young migrator left behind when the migration failed. It is scared and weak. The kid helps it, and by wandering rather than guiding, it leads them to an old tree deep in the woods, where they discover the treehouse ruin together.

**The treehouse.** The ancients built it high in an old tree as a waystation for the migration. Each room holds a beacon, a lantern or signal tied to one world, and the mural doors are the paths between them. The migrating creatures navigated by those beacons, the way real migrating creatures rely on landmarks and the stars.

**What broke.** When the last caretakers left, the treehouse fell into ruin and the beacons went dark one by one. Without them, the migration lost its way. Each world lost the creatures that pollinated its plants and spread its seeds, began to go quiet, and the blight moved in.

**The ancients.** Long ago, a community of naturalists lived in the treehouse as its caretakers, tending its beacons and the paths between worlds and passing the role from one generation to the next. The last generation left to follow the migration, expecting someone to come after them. No one did, for too long. They left carvings, murals, tools and rooms woven into the branches. They are an original culture, framed as fellow scientists, and the game reveals their story only in pieces.

**Creature symbols.** The ancients wrote in pictographs of creatures and behaviors. A symbol becomes readable once the kid understands that creature in real life, revealing clues, hidden doors and story.

**The great mural.** A cracked mural at the heart of the treehouse shows the migration cycle. Restored sections become doorways to other worlds.

**The blight.** Shadows, thorns and spores that spread into a weakened world, the way mold or invasive species take hold in a struggling habitat. Restoring a world pushes it back. It is the only thing kids fight.

**The ending.** Each restored room relights its beacon and reconnects its world. In the finale, one large chain reaction across all worlds lights the last beacon, the whole treehouse glows, and the migration finds its way back through it. The kid's own journal pages go up on the empty wall at the end of the ancients' mural, the space they left for the next caretaker.

## Player character

The player is a young naturalist whom kids can customize, carrying a backpack and a field journal everywhere.

- **Customizable.** Kids choose how their naturalist looks, so the hero feels like theirs.
- **The backpack.** Always on screen and always with them. It holds finds such as rope, pulleys, shells and seeds, starting with about 6 slots and growing to 12 as pockets are earned. Items can be combined inside it, and silly wrong combinations are their own small mistake loop. Patches, pins and charms earned on the adventure decorate it. A small beacon charm on the backpack returns the kid home at any time.
- **The field journal.** The kid's personal record of every creature: drawings, names, guesses and confirmed facts. See Mechanics.
- **The silent companion.** The lost young migrator from the opening. It never speaks, follows the kid everywhere, reacts to discoveries, and grows stronger as each world heals, perhaps growing wings by the end. It carries the story's stakes: kids care about the treehouse because they care about it.

## Core loop

Explore a world, figure out its creatures, carry what you find home, and build the treehouse into something that opens the next discovery.

Four nested loops, each rewarding the next:

| Loop | Time | What happens | Reward |
| --- | --- | --- | --- |
| Moment | Seconds | Explore, tap, react | A reaction |
| Discovery | 2–5 minutes | Spot, sketch, guess, test, stamp | A new ability or helper |
| Expedition | One session | Gather, return home, build | A build that opens something |
| Restoration | Whole game | Relight the treehouse beacons | The treehouse glows again |

The discovery loop is the core. Full detail, including an example first session, is in the [core game loop doc](https://claude.ai/artifact/Tw9KMmzK6YoGX49a2VmuBR).

## First-time experience

The first 15 minutes teach every core skill through helping the lost creature, with no text tutorials.

| Minute | What happens | What it teaches |
| --- | --- | --- |
| 0–1 | Dusk in the woods near the kid's home. A small cry. A clumsy young creature is stuck behind a fallen branch. | Moving with the stick |
| 1–2 | A small gap stands between them. The kid jumps across. | Jump |
| 2–4 | The creature is weak and hungry. The kid offers what's nearby: a leaf gets a sniff and a turned-away head, a berry gets eaten. | Use, and the first guess-and-test |
| 4–5 | The journal opens for the first time: "Ruled out" for the leaf, "Confirmed" for the berry. The kid can sketch the creature and name it, or skip. | The journal, stamps, drawing and naming |
| 5–7 | Stronger now, the creature wanders deeper into the woods and the kid follows. Glowing plants and puffballs react along the path. | Tapping the world, following the companion |
| 7–9 | An old tree with a ruined treehouse. The kid climbs up. Inside, the creature sniffs at a carving of its own kind, which the kid can now read: it shows a dark beacon. | Reading the companion's hints, readable symbols |
| 9–10 | The kid relights the first beacon. A mural section glows and opens a doorway. | The treehouse as home, beacons, mural doors |
| 10–14 | The first world: Bubble Toad's discovery loop, with the companion's hints if needed. The kid finds rope and a pulley. | The full discovery loop, the backpack |
| 14–15 | Home with the beacon charm. The kid builds a pulley lift, reviews the journal by lamplight, and the creature curls up to sleep. | Building, returning home, a natural stopping point |

Teaching rules:

- No text tutorials. Each control appears when it's needed, with a gentle visual pulse only if the kid hesitates.
- One new idea at a time.
- Nothing in the first 15 minutes can cost progress.
- The first guess-and-test is about the companion: low stakes, and it makes kids care about it before any puzzle.
- The companion's journal page starts here and keeps filling in across the whole game.
- No reading required. Journal prompts can be read aloud.

## Mechanics

The game's systems all exist to turn understanding into abilities, items into builds, and builds into new places to explore.

### Controls

An on-screen analog stick on the left moves the kid; Jump and Use buttons sit on the right. Tapping objects in the world interacts with them directly. Platforming is forgiving: wide ledges, no fall damage, and a fall returns the kid to the last safe spot.

### Discovery and creatures

Each creature has 2–4 facts. Kids spot it, sketch and name it, guess a fact, test it in the world, and get a stamp: orange "Confirmed" or blue "Ruled out." The first fact always unlocks traversal; the rest add depth.

A confirmed fact can unlock traversal, a job the creature does, a follower, a call to play back, a way of blending in, a partnership between creatures, a life cycle, readable ancient symbols, a habitat at home, or a weakness against the blight.

Creatures run on simple shared rules rather than scripts: what attracts them, what scares them, their moods, and their schedule. Rules stay consistent across all worlds, so kids can predict and experiment, and rule collisions create unscripted chain reactions. Most puzzles have more than one solution, and finding an unintended one earns a "Found a new way!" stamp.

### The field journal

The journal has two layers. The game layer records confirmed facts and drives progression. The creative layer is free: drawing with living watercolor, colors caught from the world, sketch mode with an optional tracing outline, naming species, rubbings, pressed specimens and stickers. Wrong guesses stay on the page, crossed out. The game never grades or requires art.

### Backpack and building

Kids gather materials in the worlds, combine them, and build at the treehouse workbench. Every build opens something.

| Build | Made from | Opens |
| --- | --- | --- |
| Pulley lift | Rope, pulley, basket | The treehouse's upper level and high ledges |
| Rain-barrel pond | Barrel, lily pad, water | A home for Bubble Toads |
| Moss lantern | Jar, glowmoss, string | Dark paths and night creatures |
| Diving bell | Bucket, glass, rope | Underwater areas |

### The treehouse

The home base, restored room by room. Each restored world reveals a mural section, opens a room with a new tool (lens bench, lantern loft, listening room, lookout) and relights that room's beacon. Kids build habitats that invite understood creatures to live nearby, and decorate rooms with their journal art, caught colors and collected objects. Decorations are earned, never sold.

### The companion

The silent companion makes the kid better at discovering; it never discovers for them.

- **It is the hint system.** Its behavior escalates after missed guesses: first it just follows, then it looks toward something important, then it sniffs or tugs toward it. Kids learn to read their friend the way they read other creatures.
- **It helps with shy creatures.** As a young migrator, other creatures trust it. Some skittish creatures let the kid near only after the companion approaches first.
- **It senses the blight.** It shivers or hides behind the kid when blight is near. It never fights.
- **It responds to the kid's art.** When a drawing is finished, it peeks at it and does a happy wiggle, celebrating without grading.
- **It is a discovery of its own.** Its journal page fills in across the whole game through the same guess-and-test loop: favorite food, fears, what makes it happy.

It gains one ability for each restored world, based on real migrating creatures. Which world grants which is still open.

| Ability | What it does |
| --- | --- |
| Faint glow | Lights a dark corner for a moment |
| Small paws | Squeezes through gaps to fetch items or pull a lever on the other side |
| Homing sense | Senses the direction of hidden mural doors and paths, as real migrators navigate by the Earth's magnetism and the stars |
| A call | Draws nearby creatures closer |
| Wings | Short glides with the kid, late in the game |

Guardrails: it never solves a puzzle on its own, it can't be hurt or lost, and if it falls behind it simply catches up. The one command is tapping a spot to send it there; everything else it does on its own.

### The blight

The only enemies. Kids push blight back with the Use button: a lantern flash, a seed pod or a splash of water. Blight bursts into petals or light rather than dying. Each type has a weakness tied to a creature or build, such as glowmoth light against shadow wisps. A hit knocks the kid back and may drop one backpack item. Encounters last under a minute.

### Mistakes and hints

No lives, no game over, no timers. Wrong guesses are logged as progress and retries take seconds. Hints escalate after misses but never give the answer. Younger players get fewer choices and clearer creature tells.

## Progression and structure

Knowledge opens the map: kids progress by understanding creatures, not by collecting power-ups.

Each world takes roughly 60–90 minutes and follows the same arc:

1. Arrive through a mural doorway into a world that has gone quiet.
2. Understand its 5–8 creatures, making its symbols readable and its paths open.
3. Solve its keystone puzzle, an ecosystem chain needing several creatures together.
4. Relight the world's beacon, reconnecting it to the treehouse. Color, sound and creatures return.
5. Restore the matching part of home: a mural section and a treehouse room with its tool.
6. Follow the newly revealed mural to the next world.

Cross-world dependencies, such as a diving bell built at home from items found elsewhere, encourage return trips. Travel between the treehouse and any restored world is instant.

Optional depth for curious kids: every fact on every page, look-alike species, rare night creatures, invent-a-creature pages, and naturalist ranks from Junior to Master. None of it is needed to finish the story.

## Worlds

Plan for 4–5 worlds, each a real biome given a fantastical treatment; only the first is drafted so far.

Every world is defined by the same fields. The first world, a mossy pond valley, is filled in as a working draft:

| Field | First world (draft) |
| --- | --- |
| Biome | Mossy pond and river valley |
| Science theme | Food chains and creature behavior |
| Creatures (5–8) | Bubble Toads, glowmoths, Shellbacks, burrowers; more to come |
| Blight | Shadow wisps |
| Keystone puzzle | To be designed |
| Signature build | Pulley lift |
| Treehouse room restored | Lens bench |
| Mood | Dusk light, glowing moths, soft fog |

Candidate biomes for later worlds: rainforest canopy, coral reef and tide pools, desert, frozen tundra, and deep caves. Each should carry a distinct science theme so the worlds teach different things.

## Art and audio direction

Wondrous with a touch of mystery: indie atmosphere in the spirit of Hollow Knight, Limbo and Maskborne, softened for kids.

- **Worlds.** Dark, soft and tactile, lit by glowing points of interest. Light guides the eye, so anything interactive catches light or glows. Layered depth with foreground silhouettes.
- **Creatures.** Strong, readable silhouettes that work on small screens, with clear animated "tells" kids can learn to read.
- **The journal.** Ink and watercolor on cream paper, like an old naturalist's field guide. Kids' own drawings are part of the look.
- **The ancients.** Woven rope, carved wood, shell mosaics and glowing moss. The kid's patched-together repairs blend with it over time.
- **Time of day.** Dawn, day, dusk and night repaint the same scenes, tie into creature schedules, and stretch each background further.
- **Tone.** More Studio Ghibli than horror. No gore, no frightening deaths.
- **Audio.** Quiet ambient music, rich nature sounds, and a distinct voice or call for every creature, which also feeds the listening-room mechanic. Sound carries much of the atmosphere at low cost.

Art mockups and the time-of-day palettes are on the [art concept canvas](https://claude.ai/artifact/CG4YU4vN8ybTSBhoqjyBDz). Decided: hand-painted 2D, with characters animated as cutout rigs.

### Reference board

References set principles such as light, scale and depth, never designs to copy. Each one records its source, category, what works, what to watch for, and your own notes.

#### Glowing forest floor

![Maskborne: a tiny glowing hero on a soft, mossy forest floor](references/forest.png)

- **Source:** Maskborne
- **Category:** Environment, lighting
- **What works:** The tiny hero is the brightest thing on screen, so it reads instantly. Soft, felt-like textures, a blurred foreground and glowing points of interest give depth without clutter.
- **Watch for:** The small white hero with a dark mask-like face is strongly tied to this game; our naturalist needs its own silhouette.
- **Your notes:** Also like the light casts.

#### Night water

![Maskborne: a large creature with glowing dotted outlines rising from dark water at night](references/night-water.png)

- **Source:** Maskborne
- **Category:** Environment, creatures, lighting
- **What works:** Dotted glowing outlines and bright ripples make a large creature readable in near darkness. Strong silhouettes against a dark sky.
- **Watch for:** Scenes this dark may feel spooky to younger kids; keep a warm light source nearby.
- **Your notes:** Interesting water effect. Kept simple with reflection and ripples.

#### The giant sleeping frog

![Maskborne: a giant sleeping frog lit by shafts of light beside the tiny hero on a lily pad](references/giant-frog.png)

- **Source:** Maskborne
- **Category:** Creatures, scale
- **What works:** A huge, gentle creature beside a tiny hero creates wonder rather than fear. Shafts of light frame it. The hanging carved objects hint at an older culture, which suits the ancients.
- **Watch for:** Hanging masks are a signature motif of this game; the ancients need their own symbols.
- **Your notes:**

#### Misty hall

![Hollow Knight: the hero in a misty, hand-drawn hall with a small corner HUD](references/misty-hall.png)

- **Source:** Hollow Knight
- **Category:** Environment, HUD
- **What works:** Crisp hand-drawn 2D with misty light and layered depth. The HUD stays small in one corner.
- **Watch for:** Its HUD shows health and currency; ours has no health bar. The combat framing doesn't fit.
- **Your notes:**

## UI and HUD

The HUD stays minimal so the world does the talking.

- **In the world:** analog stick (left), Jump and Use buttons (right), the backpack, a journal button with a new-entry dot, and a small location name on arrival. A "?" floats over creatures not yet understood. No health bar.
- **Touch sizing:** large buttons and a floating stick that appears where the thumb lands, sized for small hands.
- **The journal:** opens as a two-page spread. Time pauses while drawing.
- **Parent gate:** a press-and-hold check before saving or printing journal pages, and before any settings or links out of the game.
- **Reading load:** little required text. Icons, stamps and creature behavior carry meaning so early readers can play, with optional read-aloud for journal prompts.

## Business model, privacy and safety

Parents pay, so the game earns their trust first.

**Business model (undecided between):**

- Free first world as a demo, then a one-time unlock for the full game.
- A parent subscription with new worlds or seasonal creatures over time.
- A pitch to Apple Arcade or Netflix Games to fund development.
- School and classroom licenses later, once a teacher view exists.

**Firm rules:**

- No ads and no purchases aimed at kids. Decorations and cosmetics are earned only.
- Kids' drawings, writing and any voice recordings stay on the device.
- No sharing between kids. Saving or printing pages goes through the parent gate.
- Build to meet COPPA and the Apple Kids Category and Google Families rules from day one; confirm details with a privacy professional before launch.

## Technology

Built in Godot with scenes for everything visible and scripts for behavior, the way the engine is designed to be used.

| What | Godot approach |
| --- | --- |
| Worlds, treehouse, player, HUD, journal | Scenes built and arranged in the editor |
| Creatures | One base Creature scene; each species is an inherited scene with its own art and settings |
| Creature rules | Small reusable rule nodes (such as AttractedBy or ScaredByShadow) added to a creature in the editor |
| Creature facts, items, build recipes | Resource files edited in the inspector |
| Journal, backpack, progress | Autoload scripts holding game-wide state |
| Communication between systems | Signals, such as a creature emitting "fact confirmed" for the journal to hear |
| Touch controls | On-screen stick and buttons as UI nodes |

The game is 2D. Characters are cutout rigs: layered parts parented in a node tree and animated with AnimationPlayer, while code handles secondary motion such as the scarf and lantern swinging.

## Production plan

Build in four phases, and don't move on until real kids' play passes each gate.

1. **One-screen prototype:** the player, one Bubble Toad, a leaf and a moth; the guess-and-test loop and nothing else. *Gate: kids replay it without being asked.*
2. **Systems prototype:** 3–4 creatures with 3–4 rules each, journal stamps and the mistake loop. *Gate: playtesters find unplanned interactions.*
3. **Vertical slice:** the first world polished end to end (journal, backpack, one build, one treehouse room, blight); doubles as the demo and the pitch. *Gate: ready to pitch or release as a demo.*
4. **Full production:** remaining worlds, the finale and polish, then launch on iOS and Android.

Before phase 1, Godot's official "Your first 2D game" tutorial covers the scenes, scripts and signals the prototype needs. The journal's creative tools and the treehouse wait until the guess-and-test loop is fun on its own.

## Open questions

These decisions are still open and block later production work.

- [ ] Which 4–5 worlds, and which science theme does each carry?
- [x] Hand-painted 2D or stylized 2.5D? Decided: hand-painted 2D.
- [ ] At the end, does the companion leave with the migration, stay with the kid, or migrate and come back to visit?
- [ ] Are backpack items used up by builds, or reusable?
- [ ] Which business model: one-time unlock, subscription, or a platform deal?
- [ ] What is the first world's keystone puzzle?
- [ ] How much can kids customize their naturalist?
- [ ] Which restored world grants which companion ability?
- [ ] Does the companion have an official name for marketing, with kids free to rename it?
